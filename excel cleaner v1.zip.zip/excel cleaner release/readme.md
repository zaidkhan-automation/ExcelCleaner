Excel Data Cleaner — Quick Start

1. Extract the ZIP to any folder.
2. Open the folder and double-click: excel_cleaner.exe
3. Click "Load Excel/CSV" and choose your file (CSV or XLSX).
4. Use "Auto Clean", "Fill Missing (numeric mean)", "Drop Duplicates".
5. Click "Export Cleaned (Excel)" to save the cleaned file.

Notes:
- No Python required.
- If Windows warns, click "More info" → "Run anyway".
- For problems, send screenshots of any error.